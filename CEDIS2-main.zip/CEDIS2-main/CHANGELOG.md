## [1.9.0] - 2022-11-28
### Updates
- update to Angular 14
- update all dependencies to match the Angular 14 version

## [1.8.0] - 2022-05-06
### Updates
- update to Angular 13
- update all dependencies to match the Angular 13 version
- routing, build and configuration issues fixed

## [1.7.0] - 2020-12-15
### Updates
- update to Angular 11
- update all dependencies to match Angular 11 version

## [1.6.0] - 2020-03-12
### Updates
- update to Angular 9
- update all dependencies to match Angular 9 version

## [1.5.0] - 2018-10-04
### Changes
- update to Angular 6
- added online documentation

## [1.4.0] - 2017-08-28
### Changes for Angular 4
- added angular-cli
- update to Angular 4

## [v1.3.0] 2017-08-28
### skipped for sync with Angular 4 version convention

## [v1.2.0] 2017-08-28
### skipped for sync with Angular 4 version convention

## [1.1.1] - 2017-03-21
### Added
- added "@types/core-js": "0.9.35" in package

## [1.1.0] - 2017-03-01
### Added
- fix version numbers in package.json and CSS and JS

## [1.0.2] - 2017-02-27
### Added
- added upgrade to pro page
- fixed navbar title
- changed http://www.creative-tim.com/ with https://www.creative-tim.com/

## [1.0.1] - 2017-02-13
### small fix
- changes in routes(redirect '' to 'dashboard' + added HashLocationStrategy)
- changes in documentation
- changes in sidebar(cleaned li tags + changed z-index)
- changes in footer(added current date)

## [1.0.0] - 2016-12-14
### initial Release
